import random
import string

print("Enigma/Енигма")
print("Верзија: 00.00.01")

chars = " " + string.punctuation + string.digits + string.ascii_letters
chars = list(chars)
key = chars.copy()

random.shuffle(key)

while True:
    
    plain_text = input("Напиши поруку за енкриптвање (или унесите '/enigma izlaz' да изађете):")
    if plain_text.lower() == '/enigma izlaz':
        break
    cipher_text = ""

    for letter in plain_text:
        if letter in chars:
            index = chars.index(letter)
            cipher_text += key[index]
        else:
            cipher_text += letter  

    print(f"Оригинална порука: {plain_text}")
    print(f"Енкиптована порука: {cipher_text}")

    
    cipher_text = input("Напиши поруку за декриптовање (или унесите '/enigma izlaz' да изађете):")
    if cipher_text.lower() == '/enigma izlaz':
        break
    plain_text = ""

    for letter in cipher_text:
        if letter in key:
            index = key.index(letter)
            plain_text += chars[index]
        else:
            plain_text += letter 

    print(f"Оригинална порука: {cipher_text}")
    print(f"Декриптована порука: {plain_text}")
