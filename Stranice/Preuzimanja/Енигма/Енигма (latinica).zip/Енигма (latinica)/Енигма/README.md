

# Enigma

## Autor
Crnobog

## Godina nastanka programa
Jesen Gospodnje: 2023

## Opis
Enigma je alat za jednostavno enkriptovanje i dekriptovanje teksta. Pogodan je za šifrovanje poruka, dokumenata i drugih vidova tekstualnog sadržaja.

## Instalacija
1. Klonirajte repozitorijum
2. Instalirajte neophodne biblioteke
3. Pokrenite program

## Upotreba
- Za enkriptovanje teksta, pokrenite program i pratite uputstva.
- Za dekriptovanje, uradite isto kao i za enkriptovanje, ali izaberite opciju za dekriptovanje.