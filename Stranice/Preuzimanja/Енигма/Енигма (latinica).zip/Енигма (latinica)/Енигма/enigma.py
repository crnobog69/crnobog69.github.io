import random
import string

print("Enigma/Енигма")
print("Verzija: 00.00.01")

chars = " " + string.punctuation + string.digits + string.ascii_letters
chars = list(chars)
key = chars.copy()

random.shuffle(key)

while True:
   
    plain_text = input("Napiši poruku za enkriptoivanje (ili unesite '/enigma izlaz' da izađete):")
    if plain_text.lower() == '/enigma izlaz':
        break
    cipher_text = ""

    for letter in plain_text:
        if letter in chars:
            index = chars.index(letter)
            cipher_text += key[index]
        else:
            cipher_text += letter  

    print(f"Originalna poruka: {plain_text}")
    print(f"Enkriptovana poruka: {cipher_text}")

   
    cipher_text = input("Napiši poruku za dekriptovanje (ili unesite '/enigma izlaz' da izaćete):")
    if cipher_text.lower() == '/enigma izlaz':
        break
    plain_text = ""

    for letter in cipher_text:
        if letter in key:
            index = key.index(letter)
            plain_text += chars[index]
        else:
            plain_text += letter  

    print(f"Originalna poruka: {cipher_text}")
    print(f"Enkriptovana poruka: {plain_text}")
