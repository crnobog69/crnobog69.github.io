from PyQt5.QtWidgets import QApplication, QWidget, QLineEdit, QPushButton, QVBoxLayout, QHBoxLayout, QTabWidget, QMenu, QStyleFactory
from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEngineProfile
from PyQt5.QtCore import QUrl, Qt
from PyQt5.QtGui import QIcon, QPalette, QColor  
import sys

class BrowserApp(QWidget):
    def __init__(self):
        super(BrowserApp, self).__init__()
        self.setWindowIcon(QIcon('Resursi/spektar.ico'))  
        self.initUI()

    def initUI(self):
        # Постављање тамне теме
        app.setStyle(QStyleFactory.create('Fusion'))
        palette = QPalette()
        palette.setColor(QPalette.Window, QColor(53, 53, 53))
        palette.setColor(QPalette.WindowText, Qt.white)
        palette.setColor(QPalette.Base, QColor(25, 25, 25))
        palette.setColor(QPalette.AlternateBase, QColor(53, 53, 53))
        palette.setColor(QPalette.ToolTipBase, Qt.white)
        palette.setColor(QPalette.ToolTipText, Qt.white)
        palette.setColor(QPalette.Text, Qt.white)
        palette.setColor(QPalette.Button, QColor(53, 53, 53))
        palette.setColor(QPalette.ButtonText, Qt.white)
        palette.setColor(QPalette.BrightText, Qt.red)
        palette.setColor(QPalette.Link, QColor(42, 130, 218))
        palette.setColor(QPalette.Highlight, QColor(42, 130, 218))
        palette.setColor(QPalette.HighlightedText, Qt.black)
        app.setPalette(palette)

        self.resize(1000, 800)

        
        self.url_input = QLineEdit(self)
        self.url_input.setPlaceholderText('Унесите URL или појам за претрагу...')
        self.url_input.returnPressed.connect(self.loadPage)

        self.search_button = QPushButton('Претражи', self)
        self.search_button.clicked.connect(self.loadPage)

        self.forward_button = QPushButton('Напред', self)
        self.forward_button.clicked.connect(self.goForward)

        self.back_button = QPushButton('Назад', self)
        self.back_button.clicked.connect(self.goBack)

        self.reload_button = QPushButton('Освежи', self)
        self.reload_button.clicked.connect(self.reloadPage)

        self.clear_cookies_button = QPushButton('Обриши колачиће', self)
        self.clear_cookies_button.clicked.connect(self.clearCookies)

        self.new_tab_button = QPushButton('Нови таб', self)
        self.new_tab_button.clicked.connect(self.newTab)

        self.close_tab_button = QPushButton('Затвори таб', self)
        self.close_tab_button.clicked.connect(self.closeTab)

        self.tabWidget = QTabWidget()
        self.tabWidget.setTabsClosable(True)
        self.tabWidget.tabCloseRequested.connect(self.closeSpecificTab)
        self.tabWidget.currentChanged.connect(self.updateUrlInput)
        self.newTab()

        self.nav_layout = QHBoxLayout()
        self.nav_layout.addWidget(self.back_button)
        self.nav_layout.addWidget(self.forward_button)
        self.nav_layout.addWidget(self.reload_button)
        self.nav_layout.addWidget(self.url_input)
        self.nav_layout.addWidget(self.search_button)
        self.nav_layout.addWidget(self.clear_cookies_button)
        self.nav_layout.addWidget(self.new_tab_button)
        self.nav_layout.addWidget(self.close_tab_button)
        
        self.layout = QVBoxLayout()
        self.layout.addLayout(self.nav_layout)
        self.layout.addWidget(self.tabWidget)
        
        self.setLayout(self.layout)
        
        self.setWindowTitle('Спектар//Претраживач')
        self.show()

    def loadPage(self):
        query = self.url_input.text()
        if query.startswith('http://') or query.startswith('https://'):
            url = query
        else:
            url = f"https://duckduckgo.com/?q={query}"
        current_tab = self.tabWidget.currentWidget()
        current_tab.setUrl(QUrl(url))

    def goForward(self):
        current_tab = self.tabWidget.currentWidget()
        current_tab.forward()

    def goBack(self):
        current_tab = self.tabWidget.currentWidget()
        current_tab.back()

    def reloadPage(self):
        current_tab = self.tabWidget.currentWidget()
        current_tab.reload()

    def clearCookies(self):
        profile = QWebEngineProfile.defaultProfile()
        store = profile.cookieStore()
        store.deleteAllCookies()

    def newTab(self):
        new_tab = QWebEngineView()
        new_tab.setUrl(QUrl("https://duckduckgo.com/"))
        new_tab.urlChanged.connect(self.updateUrlInput)
        new_tab.titleChanged.connect(self.updateTabTitle)
        i = self.tabWidget.addTab(new_tab, "Нови таб")
        self.tabWidget.setCurrentIndex(i)

    def closeTab(self):
        current_index = self.tabWidget.currentIndex()
        if current_index >= 0:
            self.tabWidget.removeTab(current_index)

    def closeSpecificTab(self, index):
        if index >= 0:
            self.tabWidget.removeTab(index)

    def updateUrlInput(self):
        current_tab = self.tabWidget.currentWidget()
        if current_tab:
            current_url = current_tab.url().toString()
            self.url_input.setText(current_url)

    def updateTabTitle(self, title):
        current_tab = self.tabWidget.currentWidget()
        if current_tab:
            index = self.tabWidget.indexOf(current_tab)
            self.tabWidget.setTabText(index, title)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setWindowIcon(QIcon('Resursi/spektar.ico'))  
    ex = BrowserApp()
    sys.exit(app.exec_())
